# random numbers for dice
import random

dado1 = random.randint(1, 6)
dado2 = random.randint(1, 6)
print(f'Dado 1 = {dado1} y Dado 2 = {dado2}')
